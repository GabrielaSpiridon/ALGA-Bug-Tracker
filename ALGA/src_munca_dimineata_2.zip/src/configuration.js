let configuration = {
    currentUserId : 0,
  };


  
  export default configuration;