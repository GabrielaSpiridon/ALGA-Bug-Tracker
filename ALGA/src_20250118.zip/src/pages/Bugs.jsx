// Bugs.jsx
import React from 'react';

function Bugs() {
  return (
    <div style={{ padding: '20px' }}>
      <h2>Bugs</h2>
      <p>Track your bugs here.</p>
    </div>
  );
}

export default Bugs;
